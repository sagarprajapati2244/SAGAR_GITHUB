package com.example.sqlitedatabase

class UserModal(var user_id:Int , var user_name : String , var user_email:String , var user_pass : String , var user_phone : String)
{

}