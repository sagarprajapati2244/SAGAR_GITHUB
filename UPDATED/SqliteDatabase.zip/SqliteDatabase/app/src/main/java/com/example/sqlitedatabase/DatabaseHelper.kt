package com.example.sqlitedatabase

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(var context: Context):SQLiteOpenHelper(context , DATABASE_NAME , null , DATABASE_VERSION)
{
    companion object
    {
        private final var DATABASE_NAME = "user"
        private final var DATABASE_VERSION = 1

        private const val TABLE_NAME = "student"
        private const val KEY_ID = "id"
        private const val KEY_USERNAME = "username"
        private const val KEY_EMAIL = "email"
        private const val KEY_PASSWORD = "password"
        private const val KEY_MOBILE = "phone"



    }

    override fun onCreate(p0: SQLiteDatabase?) {

        //table creation
        //create table tablename (id integer primary key autoincrement , email varchar (20)....)


        val CREATE_TABLE = ("CREATE TABLE " + TABLE_NAME+"( "+ KEY_ID+" INTEGER PRIMARY KEY AUTOINCREMENT ," + KEY_USERNAME + " TEXT ," +
                KEY_EMAIL + " TEXT ," + KEY_PASSWORD + " TEXT ," + KEY_MOBILE + " TEXT )" )

        p0?.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
    }

    fun insertData(userModal: UserModal) : Long{

        var db = this.writableDatabase
        var contentValues = ContentValues()

        contentValues.put(KEY_USERNAME , userModal.user_name)
        contentValues.put(KEY_EMAIL , userModal.user_email)
        contentValues.put(KEY_PASSWORD , userModal.user_pass)
        contentValues.put(KEY_MOBILE , userModal.user_phone)

        var insertData = db.insert(TABLE_NAME , null , contentValues)
        return insertData

    }
}